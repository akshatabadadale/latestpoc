import { Component, OnInit } from "@angular/core";
import { ServiceService } from "../service.service";
import { editbook } from "../model/editbook";
import { book } from "../model/book";
import { Router } from "@angular/router";

@Component({
  selector: "app-edit-book",
  templateUrl: "./edit-book.component.html",
  styleUrls: ["./edit-book.component.css"]
})
export class EditBookComponent implements OnInit {
  editbook: editbook;
  bookArr: book[] = [];
  constructor(private serviceService: ServiceService, private router: Router) {
    this.editbook = new editbook();
  }

  ngOnInit() {
    this.getAll();
  }
  getAll() {
    console.log(this.bookArr);
    this.serviceService.bookDetails().subscribe(books => {
      this.bookArr = books;
      // this.dataSource = new MatTableDataSource(this.bookArr);
    });
  }
  storeDetails() {
    this.serviceService.storeBookDetails(this.editbook);
  }

  book(book: any) {
    throw new Error("Method not implemented.");
  }
}
