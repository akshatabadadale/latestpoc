import { Component, OnInit } from "@angular/core";
import { MatTableDataSource } from "@angular/material";
import { Router } from "@angular/router";
import { book } from "../model/book";
import { editbook } from "../model/editbook";
import { Registration } from "../model/registration";
import { ServiceService } from "../service.service";

@Component({
  selector: "app-book",
  templateUrl: "./book.component.html",
  styleUrls: ["./book.component.css"]
})
export class BookComponent implements OnInit {
  [x: string]: any;
  displayedColumns = [
    "isbn",
    "bookTitle",
    "publishingYear",
    "noOfCopiesActual",
    "noOfCopiesCurrent",
    "actions"
  ];
  dataSource;
  registeredDetails: Registration;
  bookArr: book[] = [];
  constructor(private serviceService: ServiceService, private router: Router) {
    this.registeredDetails = new Registration();
    // this.book = new book();
  }

  ngOnInit() {
    this.getAll();
  }
  getAll() {
    console.log(this.bookArr);
    this.serviceService.bookDetails().subscribe(books => {
      this.bookArr = books;
      this.dataSource = new MatTableDataSource(this.bookArr);
    });
  }
  navigateToEdit() {
    this.router.navigate(["/edit-book"]);
  }
  deleteByIsbn(isbn: number) {
    this.serviceService.deleteBook(isbn).subscribe(result => {
      this.bookArr = result;
      this.dataSource = new MatTableDataSource(this.bookArr);
    });
  }
  editBookByIsbn(isbn: number) {
    this.router.navigate(["/edit-book"]);
    //this.serviceService.editbook(isbn);
    this.serviceService.editbook(isbn).subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      }
    );
  }

  issueBookByIsbn() {
    this.book.isbn = this.Registration.employeeId;
    this.router.navigate(["/home"]);
  }
}
