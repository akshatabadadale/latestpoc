import { Registration } from './../model/registration';
import { ServiceService } from '../service.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import * as sha1 from 'sha1/sha1';
import { Login } from '../model/login';
import { MatSnackBar, MatIcon } from '@angular/material';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  inputEmail: string;
  conversionEncryptOutput: string;
  login: Login;
  hide = true;
  // employeeId = new FormControl('', [Validators.required, Validators.employeeId]);
  passwordControl = new FormControl('', [Validators.required]);

  constructor(private service: ServiceService, private router: Router, private snackBar: MatSnackBar ) {
    this.login = new Login();
    this.login.employeeId= 173566;
    this.login.password="Abcd@1234"
  }
  ngOnInit() { }

  // set validaion error message for email
  // getErrorMessage() {
  //   return this.employeeId.hasError('required')
  //     ? 'employeeId is required'
  //     : this.employeeId.hasError('employeeId')
  //       ? 'Not a valid employeeId'
  //       : '';
  // }
  loginn() {
    console.log('login');
  }
  encryptPassword() {
    // using crypto js

    /*this.conversionEncryptOutput = CryptoJS.AES.encrypt(
      this.logon.password.trim(),
      this.logon.email.trim()
    ).toString();*/

    // using sha1
    this.conversionEncryptOutput = sha1(this.login.password);
    this.login.password = this.conversionEncryptOutput;
  }
  // addOneUser() {
  //   this.service.postOne(this.login).subscribe(
  //     result => {
  //       console.log(result);
  //       localStorage.setItem('EMPLOYEE', JSON.stringify(result as Registration));

  //       // console.log(JSON.parse(localStorage.getItem('EMPLOYEE')));
  //       // console.log("Added Successfully");
  //       this.router.navigate(["/"]);
  //     },
  //     error => {
  //       console.log(error);
  //     }
  //   );
  // }

  sendLoginCredentials() {
    this.encryptPassword();
    this.service.postOne(this.login).subscribe(
      result => {
        console.log(result);
        localStorage.setItem('user', JSON.stringify(result));
        this.service.loggedCustomer = result;
        this.service.isLogged = true;
        console.log(this.service.loggedCustomer)
        this.router.navigate(['/']);
      },
      error => {
        this.login.password = ''
        this.snackBar.open('Invalid Credentials', '', {
          duration: 4000,
        });
      }
    );
  }
  navigateToForgotPwd() {
    this.router.navigate(['/forgotpassword']);
  }
}
