import { NgModule } from '@angular/core';


import {
  MatCardModule, MatDialogModule, MatInputModule, MatTableModule,
  MatToolbarModule, MatMenuModule, MatIconModule, MatProgressSpinnerModule,
  MatNativeDateModule, MatDatepickerModule, MatCheckboxModule, MatFormFieldModule,
   MatListModule, MatRadioModule, MatGridListModule,
   MatOptionModule, MatSelectModule, MatSnackBar, MatSnackBarModule} from '@angular/material';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  imports: [

    CommonModule,
  MatToolbarModule,
  MatCardModule,
  MatInputModule,
  MatDialogModule,
  MatTableModule,
  MatMenuModule,
  MatIconModule,
  MatProgressSpinnerModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatCheckboxModule,
  MatToolbarModule,
  FormsModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatListModule,
  MatRadioModule,
  MatGridListModule,
  MatTableModule,
  MatOptionModule,
  MatFormFieldModule,
  MatSelectModule,
  ReactiveFormsModule,
  MatSnackBarModule,
  MatButtonModule



  ],

  exports: [

  CommonModule,
   MatToolbarModule,
   MatButtonModule,
   MatCardModule,
   MatInputModule,
   MatDialogModule,
   MatTableModule,
   MatMenuModule,
   MatIconModule,
   MatProgressSpinnerModule,
   MatNativeDateModule,
   MatDatepickerModule,
   MatCheckboxModule,
   MatToolbarModule,
   FormsModule,
   MatCardModule,
   MatFormFieldModule,
   MatInputModule,
   MatListModule,
   MatRadioModule,
   MatGridListModule,
   MatTableModule,
   MatOptionModule,
   MatFormFieldModule,
   MatSelectModule,
   ReactiveFormsModule,
   MatSnackBarModule



  ]
})
export class LmsMaterialModule { }
