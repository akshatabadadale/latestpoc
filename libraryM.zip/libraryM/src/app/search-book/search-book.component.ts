import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { book } from '../model/book';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-search-book',
  templateUrl: './search-book.component.html',
  styleUrls: ['./search-book.component.css']
})
export class SearchBookComponent implements OnInit {
  [x: string]: any;
  dataSource;
  bookArr: book[] = [];
  displayedColumns = ['isbn', 'bookTitle', 'publishingYear', 'noOfCopiesActual', 'noOfCopiesCurrent'];
  constructor(private serviceService: ServiceService) {
    this.book = new book();
  }

  ngOnInit() {
    this.getBook();
  }
  
  books: book;
  getBook() {
    console.log(this.bookArr);
    this.serviceService.searchBook(this.book).subscribe(books => {
     this.bookArr = books;
     this.dataSource = new MatTableDataSource(this.bookArr);
    })

  }
}
