import { ServiceService } from "./../service.service";
import { Component, OnInit } from "@angular/core";

import { MatTableDataSource } from "@angular/material";
import { dvd } from "../model/dvd";

@Component({
  selector: "app-dvd",
  templateUrl: "./dvd.component.html",
  styleUrls: ["./dvd.component.css"]
})
export class DvdComponent implements OnInit {
  [x: string]: any;
  displayedColumns = [
    "dvdNo",
    "dvdTitle",
    "publishingYear",
    "noOfCopiesActual",
    "noOfCopiesCurrent"
  ];
  dataSource;
  dvdArr: dvd[] = [];

  constructor(private serviceService: ServiceService) {}

  ngOnInit() {
    this.getAll();
  }

  getAll() {
    console.log(this.dvdArr);
    this.ServiceService.dvdDetails().subscribe(dvds => {
      this.dvdArr = dvd;
      this.dataSource = new MatTableDataSource(this.dvdArr);
    });
  }
}
