import { ServiceService } from "./../service.service";
import { Component, OnInit } from "@angular/core";
import { dvd } from "../model/dvd";

@Component({
  selector: "app-add-dvd",
  templateUrl: "./add-dvd.component.html",
  styleUrls: ["./add-dvd.component.css"]
})
export class AddDvdComponent implements OnInit {
  dvd: dvd;
  constructor(private service: ServiceService) {
    this.dvd = new dvd();
  }

  ngOnInit() {}
  addDvd() {
    this.service.add(this.dvd).subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      }
    );
  }
}
