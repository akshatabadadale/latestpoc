package com.cg.entity;

public class Employee {
	private Integer id;
	private String name;
	private String dateOfJoining;

	public Employee(int id, String name, String localDate) {
		this.id = id;
		this.name = name;
		this.dateOfJoining = localDate;
	}

	@Override
	public String toString() {
		return " { id=" + id + ", name=" + name + ", dateOfJoining=" + dateOfJoining + "}";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
