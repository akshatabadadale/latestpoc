package com.cg.demo;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.entity.Employee;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class BindingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BindingDemoApplication.class, args);
		ObjectMapper mapper = new ObjectMapper();
		 try {
		  
		  List<Employee> ppl = Arrays.asList(mapper.readValue(new File("/Users/abadadal/Documents/My Received Files/demo/EmployeeList.json"),Employee[].class));
		  System.out.println(ppl);
		 } catch (JsonGenerationException e) {
		  e.printStackTrace();
		 } catch (JsonMappingException e) {
		  e.printStackTrace();
		 } catch (IOException e) {
		  e.printStackTrace();
		 }
		
	}


}