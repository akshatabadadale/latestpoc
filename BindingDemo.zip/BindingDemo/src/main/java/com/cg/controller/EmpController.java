package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.demo.BindingDemoApplication;
import com.cg.entity.Employee;
import com.cg.service.EmpService;

@CrossOrigin("http://localhost:4200")
@RestController
public class EmpController {
	
	@Autowired
	EmpService service;
	
	@Autowired
	BindingDemoApplication maindemo;
	
	@GetMapping(value = "/getsorted", produces = "application/json")
	public List<Employee> getSorted() {
		List<Employee> result = null;
		return result;

	}
	
//	@GetMapping(value = "/getsortedbyname" ,produces ="application/json")
//	public List<Employee> getSortedByName(){
//		System.out.println(service.ppl2());
//		return service.ppl2();
//
//	}

}
