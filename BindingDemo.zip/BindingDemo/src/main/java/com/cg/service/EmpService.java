package com.cg.service;

import org.springframework.stereotype.Service;
@Service
public class EmpService {
	

		
		 //List<Employee> pp = new ArrayList<Employee>();
		
		
		

		
		 //Collections.sort(listOfEmployees, new EmployeeDojSorter());
		
 
		 // Sorted by firstName

		//Collections.sort(pp, new EmployeeNameSorter());
		
		//sort by ID
		
		//Collections.sort(pp,new EmployeeIdSorter());
        
		//return pp;
	
	}

