package com.cg.demo.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.demo.entity.Employee;
import com.cg.demo.service.EmployeeService;

@CrossOrigin(allowedHeaders = "*", origins = "*")
@RestController
public class EmpController {

	@Autowired
	private EmployeeService employeeService;

	// to get employee List
	@GetMapping(path = "/employees", produces = "application/json")
	public List<Employee> getAll() {

		return employeeService.getAll();
	}

	// Sorting logic
	// global initialization
	Comparator<Employee> sortById;
	Comparator<Employee> sortByName;
	Comparator<Employee> sortByDateOfJoining;

	// Constructor initialization
	public EmpController() {
		sortById = (Employee emp1, Employee emp2) -> emp1.getId().compareTo(emp2.getId());
		sortByName = (Employee emp1, Employee emp2) -> emp1.getName().compareTo(emp2.getName());
		sortByDateOfJoining = (Employee emp1, Employee emp2) -> emp1.getDateOfJoining()
				.compareTo(emp2.getDateOfJoining());
	}


	//to get json file from front end and apply logic
	@PostMapping(path = "/employees/{sortType}",  produces = "application/json", consumes = {"multipart/form-data"})
	public List<Employee> sortById(@PathVariable("sortType") String type ,@RequestParam("myFile") MultipartFile file) {
		
		File convFile = new File(System.getProperty("java.io.tmpdir") +
					   "/" + file.getOriginalFilename());//will create temp directory where the file will be created properly. 
														//This way a creating temp folder, where file gets created 
		try {
			file.transferTo(convFile);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Employee> list = employeeService.getByFile(convFile);

		switch (type) {
		case "id":
			Collections.sort(list, sortById);
			break;
		case "name":
			Collections.sort(list, sortByName);
			break;
		case "doj":
			Collections.sort(list, sortByDateOfJoining);
			break;
		default:
			break;
		}

		return list;
	}
	
//	converting multipart file to file(java) 
//	@PostMapping(path = "/abc")
//	public List<Employee> upload(@RequestParam("myFile") MultipartFile file) {
//		try {
//			File convFile = new File(System.getProperty("java.io.tmpdir") + "/" + file.getOriginalFilename());//will create temp directory where your file will be created properly. 
//																											//This way you are creating temp folder, where file gets created , later on you can delete file or temp folder.
//			file.transferTo(convFile);
//			//System.out.println(convFile.getName());
//			List<Employee> list = employeeService.getByFile(convFile);
//			return list;
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IllegalStateException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		return employeeService.getAll();
//	}
//	@GetMapping(path = "/employees/{sortType}", produces = "application/json")
//	public List<Employee> sortById(@PathVariable("sortType") String type) {
//
//		List<Employee> list = employeeService.getAll();
//
//		switch (type) {
//		case "id":
//			Collections.sort(list, sortById);
//			break;
//		case "name":
//			Collections.sort(list, sortByName);
//			break;
//		case "doj":
//			Collections.sort(list, sortByDateOfJoining);
//			break;
//		default:
//			break;
//		}
//
//		return list;
//	}
	
}
