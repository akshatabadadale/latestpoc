package com.cg.demo.entity;

import java.time.LocalDate;

public class Employee {
	private Integer id;
	private String name;
	private LocalDate dateOfJoining;

	public Employee(int id, String name, LocalDate localDate) {
		this.id = id;
		this.name = name;
		this.dateOfJoining = localDate;
	}

	@Override
	public String toString() {
		return " { id=" + id + ", name=" + name + ", dateOfJoining=" + dateOfJoining + "}";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
