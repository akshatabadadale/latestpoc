package com.cg.demo.service;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.demo.entity.Employee;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@Service("employeeService")
public class EmployeeService {

	private final String PATH = "C://Users//abadadal//Downloads//EmployeeList.json";
	
	
	public List<Employee> getAll() {
		ObjectMapper mapper = new ObjectMapper();//ObjectMapper for reading and writing JSON
		try {
			// needs to register first //jackson datatype module for date& time in java
			mapper.registerModule(new JavaTimeModule());

			// parsing json to bean
			List<Employee> employeeList = Arrays.asList(mapper.readValue(new File(PATH), Employee[].class));
			return employeeList;

		} catch (JsonGenerationException e) {
			e.printStackTrace();
			return null;
		} catch (JsonMappingException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}
	
	public List<Employee> getByFile(File file) {
		ObjectMapper mapper = new ObjectMapper();//ObjectMapper for reading and writing JSON
		try {
			// needs to register first //jackson datatype module for date& time in java
			mapper.registerModule(new JavaTimeModule());

			// parsing json to bean
			List<Employee> employeeList = Arrays.asList(mapper.readValue(file, Employee[].class));
			return employeeList;

		} catch (JsonGenerationException e) {
			e.printStackTrace();
			return null;
		} catch (JsonMappingException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}
}
