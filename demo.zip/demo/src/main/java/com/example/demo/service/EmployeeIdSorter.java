package com.example.demo.service;

import java.util.Comparator;

import com.example.demo.entity.Employee;

public class EmployeeIdSorter implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getId().compareTo(o2.getId());
	}

}
