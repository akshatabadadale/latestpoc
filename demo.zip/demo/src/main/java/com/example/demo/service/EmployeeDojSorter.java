package com.example.demo.service;

import java.util.Comparator;

import com.example.demo.entity.Employee;

public class EmployeeDojSorter implements Comparator<Employee>{

//compare logic
	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getDateOfJoining().compareTo(o2.getDateOfJoining());
	}

}
