package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

@CrossOrigin("http://localhost:4200")
@RestController
public class NameController {
	
	@Autowired
	private EmployeeService service;
	
	@GetMapping(value = "/getsortedbyname" ,produces ="application/json")
	public List<Employee> getSortedByName(){
		System.out.println(service.sortedList());
		return service.sortedList();

	}
}
