package com.example.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.Employee;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class DemoApplication{

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		
		try {
			ObjectMapper mapper =new ObjectMapper();
			InputStream inputStream = new FileInputStream(new File("C:/Users/abadadal/demoApp/EmployeeList.json"));
			TypeReference<List<Employee>> typeReference = new TypeReference<List<Employee>>() {	};
			List<Employee> employees = mapper.readValue(inputStream, typeReference);
			
			for (Employee e : employees) {
				System.out.println("Id is "+ e.getId()+" name is "+ e.getName() +" Date of Joining is "+ e.getDateOfJoining() );
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

//	@Override
//	public void run(String[] args) throws IOException {
//		
//		ObjectMapper mapper =new ObjectMapper();
//
//		Employee employee = mapper.readValue(new File("EmployeeList.json"), Employee.class);
//	}

}
