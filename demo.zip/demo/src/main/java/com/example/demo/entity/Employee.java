package com.example.demo.entity;

import java.time.LocalDate;

public class Employee {

	private int id;
	private String name;
	private LocalDate dateOfJoining;

	public Employee(int id, String name, LocalDate localDate) {
		this.id = id;
		this.name = name;
		this.dateOfJoining = localDate;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", dateOfJoining=" + dateOfJoining + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

}
