package com.example.demo.service;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;

@Service
public class EmployeeService {

	public List<Employee> sortedList() {
		Employee e1 = new Employee(1, "Akshata", LocalDate.of(2019, Month.APRIL, 12));
		Employee e2 = new Employee(2, "Aditya", LocalDate.of(2019, Month.MAY, 06));
		Employee e3 = new Employee(3, "Mayur", LocalDate.of(2019, Month.JANUARY, 23));
		Employee e4 = new Employee(4, "Brij", LocalDate.of(2019, Month.MARCH, 23));
		Employee e5 = new Employee(5, "Mohit", LocalDate.of(2019, Month.FEBRUARY, 2));
		Employee e6 = new Employee(6, "Mayuresh", LocalDate.of(2019, Month.FEBRUARY, 06));
		Employee e7 = new Employee(7, "Saurabh", LocalDate.of(2019, Month.MARCH, 23));
		Employee e8 = new Employee(8, "Prioyanka", LocalDate.of(2019, Month.FEBRUARY, 8));
		Employee e9 = new Employee(9, "Ujjwala", LocalDate.of(2019, Month.MAY, 23));
		Employee e10 = new Employee(10, "Ankush", LocalDate.of(2019, Month.MARCH, 17));
		Employee e11= new Employee(11, "Amol", LocalDate.of(2019, Month.JANUARY, 1));
		Employee e12= new Employee(12, "Sujay", LocalDate.of(2019, Month.FEBRUARY, 8));
		Employee e13 = new Employee(13, "Chetan", LocalDate.of(2019, Month.FEBRUARY, 9));
		Employee e14 = new Employee(14, "Tushar", LocalDate.of(2019, Month.MAY, 23));
		Employee e15= new Employee(15, "Pranali", LocalDate.of(2019, Month.NOVEMBER, 11));
		Employee e16 = new Employee(16, "Zubair", LocalDate.of(2019, Month.FEBRUARY, 23));
		Employee e17 = new Employee(17, "YAsh", LocalDate.of(2019, Month.OCTOBER, 5));
		Employee e18= new Employee(18, "Laxmi", LocalDate.of(2019, Month.FEBRUARY, 16));
		Employee e19 = new Employee(19, "Gaurav", LocalDate.of(2019, Month.NOVEMBER, 17));
		Employee e20 = new Employee(20, "Jay", LocalDate.of(2019, Month.FEBRUARY, 23));
		
		

		List<Employee> listOfEmployees = new ArrayList<Employee>();
		listOfEmployees.add(e1);
		listOfEmployees.add(e2);
		listOfEmployees.add(e3);
		listOfEmployees.add(e4);
		listOfEmployees.add(e5);
		listOfEmployees.add(e6);
		listOfEmployees.add(e7);
		listOfEmployees.add(e8);
		listOfEmployees.add(e9);
		listOfEmployees.add(e10);
		listOfEmployees.add(e11);
		listOfEmployees.add(e12);
		listOfEmployees.add(e13);
		listOfEmployees.add(e14);
		listOfEmployees.add(e15);
		listOfEmployees.add(e16);
		listOfEmployees.add(e17);
		listOfEmployees.add(e18);
		listOfEmployees.add(e19);
		listOfEmployees.add(e20);
		
		// UnSorted List
		System.out.println("Unsorted List : " + listOfEmployees);
		Collections.sort(listOfEmployees, new EmployeeDojSorter());
		
 
		 // Sorted by firstName
     System.out.println(listOfEmployees);

     Collections.sort(listOfEmployees, new EmployeeNameSorter());

        
        return listOfEmployees;
 
       
		
	}

	

}
