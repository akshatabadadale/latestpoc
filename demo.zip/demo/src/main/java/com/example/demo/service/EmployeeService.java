package com.example.demo.service;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;

@Service
public class EmployeeService {

	public List<Employee> sortedList() {
		Employee e1 = new Employee(1, "Akshata", LocalDate.of(1988, Month.APRIL, 12));
		Employee e2 = new Employee(2, "Aditya", LocalDate.of(1988, Month.MAY, 06));
		Employee e3 = new Employee(3, "Mayur", LocalDate.of(1988, Month.JANUARY, 23));
		Employee e4 = new Employee(4, "Brij", LocalDate.of(1988, Month.MARCH, 23));
		Employee e5 = new Employee(5, "Mohit", LocalDate.of(1988, Month.FEBRUARY, 23));

		List<Employee> listOfEmployees = new ArrayList<Employee>();
		listOfEmployees.add(e1);
		listOfEmployees.add(e2);
		listOfEmployees.add(e3);
		listOfEmployees.add(e4);
		listOfEmployees.add(e5);

		System.out.println("Unsorted List : " + listOfEmployees);
		Collections.sort(listOfEmployees, new EmployeeSorter());
		
		return listOfEmployees;

	}

	

}
