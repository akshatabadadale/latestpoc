package com.capgemini.repo;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.bean.DvdDetails;

public interface DvdRepo extends CrudRepository<DvdDetails, Integer>{

}
