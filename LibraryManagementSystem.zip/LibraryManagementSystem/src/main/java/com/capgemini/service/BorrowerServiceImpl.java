package com.capgemini.service;

public class BorrowerServiceImpl implements BorrowerService {

}
