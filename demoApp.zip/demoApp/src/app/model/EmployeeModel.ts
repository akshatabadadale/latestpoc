export class employee{
  id: number;
 name: String;
dateOfJoining: Date;
}