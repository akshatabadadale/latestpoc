import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from '@angular/router';
import { employee } from './model/EmployeeModel';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {
  baseHref = "http://localhost:8087";
  constructor(private http: HttpClient, private routes: Router) { }

  sortEmpByDoj (): Observable<employee[]> {
    return this.http.get<employee[]>(this.baseHref + "/getsorted");

  }
}
