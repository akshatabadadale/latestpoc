import { Component, OnInit } from '@angular/core';
import { employee } from '../model/EmployeeModel';
import { EmpServiceService } from '../emp-service.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employee: employee[];

  constructor(private service: EmpServiceService) { }

  ngOnInit() {

  }

  sort() {
    console.log(this.employee);
    this.service.sortEmpByDoj().subscribe(data => {
      this.employee = data;
    });
  }
}
