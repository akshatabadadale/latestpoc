package com.capgemini.service;

import java.util.List;


import com.capgemini.bean.DvdDetails;

public interface DvdService {
		
	public DvdDetails addDvd(DvdDetails body);
		
	public DvdDetails editDvd(DvdDetails body);
	
	public List<DvdDetails> dvdList();
		
	public void deleteDvd(int id);
		
	public DvdDetails issueBookByDvdNo(DvdDetails body);
		

}
