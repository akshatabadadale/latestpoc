package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BookDetails;

public interface BookService {
	
	public BookDetails addBook(BookDetails body);
	
	public  BookDetails editBook(BookDetails body);
	
	public List<BookDetails> bookList();

	public void deleteBook(int id);

	public BookDetails issueBookByIsbn(BookDetails body);
}
