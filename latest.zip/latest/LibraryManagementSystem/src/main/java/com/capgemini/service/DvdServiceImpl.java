package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.DvdDetails;
import com.capgemini.repo.DvdRepo;

@Service
@Transactional
public class DvdServiceImpl implements DvdService {

	@Autowired
	DvdRepo dvdRepo;

	@Override
	public DvdDetails addDvd(DvdDetails body) {
		return dvdRepo.save(body);
	}

	@Override
	public DvdDetails editDvd(DvdDetails body) {
		return dvdRepo.save(body);
		
	}

	@Override
	public List<DvdDetails> dvdList() {
		return (List<DvdDetails>) dvdRepo.findAll();
	}

	@Override
	public void deleteDvd(int id) {
		dvdRepo.deleteById(id);
	}

	@Override
	public DvdDetails issueBookByDvdNo(DvdDetails body) {
		return dvdRepo.save(body);
	}
}
