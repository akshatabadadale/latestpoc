package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dvd_details")
public class DvdDetails {

	@Id
	@Column(name = "dvd_No")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int dvdNo;
	
	@Column(name = "dvd_title")
	private String dvdTitle;

	@Column(name = "publishing_year")
	private String publishingYear;
	
	@Column(name = "no_of_copies_actual")
	private int noOfCopiesActual;
	
	@Column(name = "no_of_copies_current")
	private int noOfCopiesCurrent;

	public int getDvdNo() {
		return dvdNo;
	}

	public void setDvdNo(int dvdNo) {
		this.dvdNo = dvdNo;
	}

	public String getDvdTitle() {
		return dvdTitle;
	}

	public void setDvdTitle(String dvdTitle) {
		this.dvdTitle = dvdTitle;
	}

	public String getPublishingYear() {
		return publishingYear;
	}

	public void setPublishingYear(String publishingYear) {
		this.publishingYear = publishingYear;
	}

	public int getNoOfCopiesActual() {
		return noOfCopiesActual;
	}

	public void setNoOfCopiesActual(int noOfCopiesActual) {
		this.noOfCopiesActual = noOfCopiesActual;
	}

	public int getNoOfCopiesCurrent() {
		return noOfCopiesCurrent;
	}

	public void setNoOfCopiesCurrent(int noOfCopiesCurrent) {
		this.noOfCopiesCurrent = noOfCopiesCurrent;
	}
	
	
	
}
