package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bean.BorrowerDetails;
import com.capgemini.service.BorrowerService;

@CrossOrigin("http://localhost:4200")
@RestController
public class BorrowController {

	@Autowired
	BorrowerService borrowerService;
	
	@PostMapping(path = "/issuebook",consumes="application/json",produces="application/json")
	public BorrowerDetails issueBook(@RequestBody BorrowerDetails borrower) {
		return borrowerService.issueBook(borrower);	
	}
}
