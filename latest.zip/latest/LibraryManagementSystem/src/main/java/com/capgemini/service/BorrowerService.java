package com.capgemini.service;

import com.capgemini.bean.BorrowerDetails;

public interface BorrowerService {

	
	public BorrowerDetails issueBook(BorrowerDetails body);
	
	
}
