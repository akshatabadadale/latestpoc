package com.capgemini.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.BookDetails;
import com.capgemini.bean.BorrowerDetails;
import com.capgemini.repo.BookRepo;
import com.capgemini.repo.BorrowerRepo;
@Service
@Transactional
public class BorrowerServiceImpl implements BorrowerService {
	
	@Autowired
	BorrowerRepo borrowerRepo;
	
	@Autowired
	BookRepo bookRepo;
	
	@Override
	public BorrowerDetails issueBook(BorrowerDetails body) {
		BookDetails book = bookRepo.findById(body.getBook().getIsbn()).get();
		book.setNoOfCopiesActual(book.getNoOfCopiesActual() -1);
		bookRepo.save(book);
		return borrowerRepo.save(body);
	}

	
	
}
