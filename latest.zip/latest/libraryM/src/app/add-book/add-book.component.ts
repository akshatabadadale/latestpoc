import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { book } from '../model/book';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {
  book: book;

  constructor(private service: ServiceService) { 
    this.book = new book();
  }

  ngOnInit() {
  }
addBook() {
  this.service.add(this.book).subscribe(
    data => {
      console.log(data);
    },
    error => {
      console.log(error);
    }
  );
}
}
