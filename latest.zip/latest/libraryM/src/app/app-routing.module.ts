import { DvdComponent } from "./dvd/dvd.component";
import { AddMagazineComponent } from "./add-magazine/add-magazine.component";
import { AddDvdComponent } from "./add-dvd/add-dvd.component";
import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { BookComponent } from "./book/book.component";
import { RegisterComponent } from "./register/register.component";
import { LoginComponent } from "./login/login.component";
import { MagazineComponent } from "./magazine/magazine.component";
import { HomeComponent } from "./home/home.component";
import { AdminComponent } from "./admin/admin.component";
import { EditBookComponent } from "./edit-book/edit-book.component";
import { StudentComponent } from "./student/student.component";
import { AddBookComponent } from "./add-book/add-book.component";
import { SearchBookComponent } from "./search-book/search-book.component";

const routes: Routes = [
  { path: "", redirectTo: "/home", pathMatch: "full" },
  { path: "home", component: HomeComponent },
  { path: "book", component: BookComponent },
  { path: "register", component: RegisterComponent },
  { path: "login", component: LoginComponent },
  { path: "magazine", component: MagazineComponent },
  { path: "admin", component: AdminComponent },
  { path: "edit-book", component: EditBookComponent },
  { path: "add-book", component: AddBookComponent },
  { path: "search-book", component: SearchBookComponent },
  { path: "student", component: StudentComponent },
  { path: "add-dvd", component: AddDvdComponent },
  { path: "add-magazine", component: AddMagazineComponent },
  { path: "dvd", component: DvdComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
