import { book } from "./book";
import { Registration } from "./registration";

export class BorrowerDetails {
  borrowerId: number;
  borrowedFromDate: String;
  borrowedToDate: String;
  actualReturnDate: String;
  book: book;
  employee: Registration;
  data: Date;
}
