import { Injectable } from "@angular/core";
import { Registration } from "./model/registration";
import { Login } from "./model/login";
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { book } from "./model/book";
import { magazine } from "./model/magazine";
import { dvd } from "./model/dvd";
import { editbook } from "./model/editbook";
import { Observable } from "rxjs";
import { admin } from "./model/admin";
import { BorrowerDetails } from "./model/BorrowerDetails";

@Injectable({
  providedIn: "root"
})
export class ServiceService {
  baseHref = "http://localhost:8888";
  public loggedCustomer: Registration = new Registration();
  public isLogged: boolean = false;
  constructor(private http: HttpClient, private routes: Router) {}

  postOne(login: Login): Observable<Registration> {
    let id = login.employeeId;
    let pass = login.password;
    return this.http.get<Registration>(
      this.baseHref + `/employeeById/${id}/${pass}`
    );
  }
  bookDetails() {
    return this.http.get<book[]>(this.baseHref + "/allbooks");
  }
  // tslint:disable-next-line: no-shadowed-variable
  add(book: book) {
    return this.http.post<book>(this.baseHref + "/addbook", book);
  }
  searchBook(book: book) {
    let id = book.isbn;
    return this.http.get<book[]>(this.baseHref + `/bookByIsbn/${id}`);
  }
  registerDetails(register: Registration) {
    return this.http.post<Login>(this.baseHref + "/addemployee", register);
  }
  deleteBook(isbn: number) {
    return this.http.delete<book[]>(this.baseHref + "/deletebook/" + isbn);
  }
  // tslint:disable-next-line: no-shadowed-variable
  editbook(isbn: number) {
    return this.http.put<book>(this.baseHref + "/editbook/", book);
  }
  issueBookByIsbn(isbn: number) {
    return this.http.get<book>(this.baseHref + "/issueBookByIsbn/" + isbn);
    //this.http.post<book>(this.baseHref + "/issueBookByIsbn/" + isbn);
  }

  addDvd(dvd: dvd) {
    return this.http.post<dvd>(this.baseHref + "/adddvd", dvd);
  }
  dvdDetails() {
    return this.http.get<dvd[]>(this.baseHref + "/alldvds");
  }
  magazineDetails() {
    return this.http.get<magazine[]>(this.baseHref + "/allmagazine");
  }

  storeBookDetails(obj: editbook): any {
    // this.recievedBook = obj;
  }
  getBookDetails() {
    // return this.receivedObj;
  }

  issueBook(data: BorrowerDetails) {
    return this.http.post<BorrowerDetails>(this.baseHref + "/issuebook", data);
  }
}
