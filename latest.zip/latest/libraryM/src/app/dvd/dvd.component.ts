import { Component, OnInit } from "@angular/core";
import { dvd } from "../model/dvd";
import { ServiceService } from "../service.service";
import { MatTableDataSource } from "@angular/material";

@Component({
  selector: "app-dvd",
  templateUrl: "./dvd.component.html",
  styleUrls: ["./dvd.component.css"]
})
export class DvdComponent implements OnInit {
  [x: string]: any;
  displayedColumns = [
    "dvdNo",
    "dvdTitle",
    "publishingYear",
    "noOfCopiesActual",
    "noOfCopiesCurrent"
  ];
  dataSource;
  dvdArr: dvd[] = [];
  constructor(private serviceService: ServiceService) {}

  ngOnInit() {
    this.getAll();
  }
  getAll() {
    console.log(this.dvdArr);
    this.ServiceService.dvdDetails().subscribe(dvds => {
      this.dvdArr = dvds;
      this.dataSource = new MatTableDataSource(this.dvdArr);
    });
  }
  // navigateToEdit() {
  //   this.router.navigate(["/edit-book"]);
  // }
  deleteDvd() {
    console.log(this.dvdArr);
    this.serviceService.dvdDetails().subscribe(dvds => {
      this.dvdArr = dvds;
      this.dataSource = new MatTableDataSource(this.dvdArr);
    });
  }
}
