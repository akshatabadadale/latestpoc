import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-magazine',
  templateUrl: './add-magazine.component.html',
  styleUrls: ['./add-magazine.component.css']
})
export class AddMagazineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
